# Machine Learning-Based Energy Efficiency Prediction and Optimization for Tata Steel

> **Evidence warning:** The default dataset is synthetic and labelled as such. This project does not contain verified Tata Steel operating data, and synthetic scores/savings must not be represented as Tata Steel findings.

## What it does
- Generates a reproducible synthetic industrial-energy dataset.
- Audits required fields and target values.
- Uses chronological train/validation/test splits.
- Compares a Dummy baseline, required ordinary Linear Regression, Ridge, Random Forest and HistGradientBoosting regression.
- Saves a fitted pipeline, JSON metrics, test predictions and diagnostic plots.
- Includes tests, a Streamlit demo dashboard, report and viva guide.

## Setup (Python 3.10+)
```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Run the reproducible synthetic demonstration
```bash
python scripts/generate_data.py
python scripts/train.py
pytest -q
streamlit run app/dashboard.py
```
Expected outputs after training:
- `outputs/models/energy_model.joblib`
- `outputs/metrics/model_metrics.json`
- `outputs/metrics/test_predictions.csv`
- `outputs/figures/predicted_vs_actual.png`
- `outputs/figures/residuals.png`

Model scores are generated when you run the code; they are intentionally not hard-coded in this README.

## Tata Steel annual benchmark (separate from model training)\nThe file `data/raw/tata_steel_annual_benchmark.csv` stores annual energy-intensity figures (GJ per tonne of crude steel) for Tata Steel Limited standalone. These annual figures are reported separately for context and are NOT used to train the interval-level model, because their time scale and target units differ. Confirm scope and methodology notes in Tata Steel's official ESG indicators factsheet: https://www.tatasteel.com/sustainability/esg-indicators-factsheet/\n\n## Public dataset option
Official UCI record: https://archive.ics.uci.edu/dataset/851/steel+industry+energy+consumption
DOI: 10.24432/C52G8C; license listed by UCI: CC BY 4.0.
The UCI dataset has 35,040 observations from a small-scale South Korean steel industry. Its schema differs from the production-aware synthetic schema in this starter project. Audit and map its fields before modeling; do not fabricate missing production, temperature or raw-material variables.

## Data dictionary for synthetic demonstration
| Field | Unit/type | Meaning |
|---|---|---|
| timestamp | datetime | Interval start, 15-minute frequency |
| production_tonnes | tonnes/interval | Simulated output |
| raw_material_tonnes | tonnes/interval | Simulated input material |
| operating_hours | hours/interval | Simulated operating duration |
| machine_load_pct | % | Simulated machine load |
| temperature_c | °C | Simulated process temperature |
| ambient_temp_c | °C | Simulated ambient temperature |
| previous_interval_energy_kwh | kWh | Previous interval energy, assumed available at prediction time |
| shift | category | Simulated shift label |
| operating_regime | category | steady/startup/maintenance |
| energy_kwh | kWh/interval | Target |
| data_origin | category | Provenance label |

## Key modeling decisions
- Time-aware split, not random split.
- Preprocessing fitted inside scikit-learn pipelines.
- Target and target-derived energy intensity excluded from predictors.
- Model selection uses validation RMSE; final test set is held back until selection.
- `sMAPE` is reported instead of ordinary MAPE to reduce instability near zero.
- Residuals are investigation signals, not proof of inefficiency.

## Limitations
Synthetic coefficients are illustrative, not calibrated to any plant. The demo is not an industrial control system. Real deployment requires authorized historian data, unit and timestamp alignment, engineering constraints, security review, validation on future periods, and monitored controlled trials.

## Reproducibility
Seed is fixed to 42 in the generator and model configuration. Record package versions and dataset hashes for formal research use.
