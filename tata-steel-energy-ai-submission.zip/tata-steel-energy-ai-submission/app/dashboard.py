from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import streamlit as st
import pandas as pd
from steel_energy.predict import load_model

st.set_page_config(page_title="Steel Energy AI Demo", layout="wide")
st.title("Steel Energy Efficiency — ML Demonstration")
st.warning("Educational demo only. Synthetic-data predictions are not Tata Steel measurements or live operating advice.")
model_path = Path("outputs/models/energy_model.joblib")
if not model_path.exists():
    st.info("Train the model first: python scripts/generate_data.py && python scripts/train.py")
    st.stop()
model = load_model(model_path)
st.subheader("Scenario input")
with st.form("scenario"):
    production = st.number_input("Production (tonnes / interval)", min_value=0.0, value=12.0)
    raw_material = st.number_input("Raw material (tonnes / interval)", min_value=0.0, value=13.4)
    hours = st.number_input("Operating hours / interval", min_value=0.0, max_value=0.25, value=0.20)
    load = st.slider("Machine load (%)", 5, 100, 70)
    temp = st.number_input("Process temperature (°C)", min_value=0.0, value=850.0)
    ambient = st.number_input("Ambient temperature (°C)", value=24.0)
    previous = st.number_input("Previous interval energy (kWh)", min_value=0.0, value=100.0)
    shift = st.selectbox("Shift", ["night", "morning", "evening"])
    regime = st.selectbox("Operating regime", ["steady", "startup", "maintenance"])
    submitted = st.form_submit_button("Predict")
if submitted:
    row = pd.DataFrame([{
        "production_tonnes": production, "raw_material_tonnes": raw_material,
        "operating_hours": hours, "machine_load_pct": load, "temperature_c": temp,
        "ambient_temp_c": ambient, "previous_interval_energy_kwh": previous,
        "shift": shift, "operating_regime": regime
    }])
    prediction = float(model.predict(row)[0])
    st.metric("Predicted interval energy", f"{prediction:,.2f} kWh")
    if production > 0:
        st.metric("Illustrative energy intensity", f"{prediction / production:,.2f} kWh/tonne")
    st.caption("Predictions depend on synthetic demonstration data and must not be used to control equipment.")
