# Learning guide: Energy prediction from first principles

## 1. Total energy versus energy intensity
- Total energy (kWh/interval) answers: how much electricity was consumed?
- Energy intensity (kWh/tonne) answers: how much electricity was used per unit of output?
- Compare intensity only for comparable process routes, product mix, equipment and operating conditions.
- If production is zero, intensity is undefined; do not silently replace it with zero.

## 2. Regression
Given predictors X and measured target y, regression learns a function f(X) that minimizes a loss on training observations. Here y is interval electricity consumption in kWh. A prediction is an estimate, not a physical guarantee.

## 3. Metrics
- MAE = mean(|y - y_hat|): average absolute error in kWh.
- RMSE = sqrt(mean((y - y_hat)^2)): penalizes large errors more heavily.
- R² = 1 - SSE/SST: relative fit against predicting the test-set mean; can be negative.
- sMAPE is used here instead of ordinary MAPE to reduce instability near zero; it still needs careful interpretation.

## 4. Leakage and time
A feature leaks when it contains information unavailable at the prediction moment or is derived from the target. Split chronologically, fit imputers/encoders/scalers on training data only, and do not use interval energy to predict that same interval. The synthetic example's lagged energy means the previous interval, not the current target.

## 5. Models
- DummyRegressor is the baseline.
- Ridge is a linear model with L2 regularization.
- Random Forest averages many decision trees and can learn nonlinear interactions.
- HistGradientBoosting adds trees sequentially to correct previous errors.
Select using validation error, then report once on the untouched test period.

## 6. Explainability and anomaly signals
Permutation importance measures how much validation score worsens when a feature is shuffled. Correlated features can share or mask importance. A positive residual (actual minus predicted) means actual energy exceeded model expectation; it does not prove waste. Investigate persistent residuals alongside production, quality, startup/shutdown, maintenance and sensor health.

## 7. Optimization caution
Changing a feature in a model input does not prove that changing the real process setting will reduce energy. Scenario analysis must enforce production, quality, safety and equipment constraints, then be reviewed by process engineers and validated in controlled trials.
