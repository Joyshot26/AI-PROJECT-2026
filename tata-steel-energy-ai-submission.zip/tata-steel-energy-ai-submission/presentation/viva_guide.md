# Presentation and Viva Guide

## 5-minute script
**0:00–0:40 — Problem:** Steelmaking uses energy in multiple process routes and energy forms. This project demonstrates prediction of interval electricity consumption and investigates deviations from expected use.
**0:40–1:20 — Data integrity:** The prototype uses labelled synthetic data by default. The UCI steel-industry dataset is a public alternative, but it is from South Korea and lacks some production variables. It is not Tata Steel data.
**1:20–2:10 — Method:** Data are time-sorted. A chronological split simulates future prediction. Imputation, encoding and scaling are fitted inside the training pipeline.
**2:10–3:00 — Models and metrics:** A mean baseline is compared with ordinary Linear Regression, Ridge, Random Forest and HistGradientBoosting using MAE, RMSE, R² and sMAPE.
**3:00–3:50 — Interpretation:** Permutation importance can show predictive reliance, not causality. Positive residuals flag periods for investigation, not proven waste.
**3:50–4:35 — Optimization:** Scenario analysis is constrained by production and operating limits. Any real change needs process-engineer review and controlled validation.
**4:35–5:00 — Conclusion:** This is a reproducible foundation; plant-specific conclusions require verified plant data.

## 10-minute script
Expand the five-minute version with: (1) total energy vs intensity, (2) data dictionary and missing feature limitations, (3) why time split prevents optimistic leakage, (4) how tree ensembles model nonlinearities, (5) residual diagnostics and subgroup error analysis, (6) cost/emissions formulas with verified factors, (7) deployment monitoring and model drift.

## 30 viva questions and answers
1. **Why regression?** The target is continuous energy use.
2. **What is the label?** `energy_kwh`, the target per interval.
3. **What is a feature?** An input available at prediction time.
4. **What is energy intensity?** Energy divided by output, here kWh/tonne when production is positive.
5. **Why not compare total energy alone?** Higher production can raise total consumption even when efficiency is unchanged.
6. **Why a baseline?** It tests whether complex models add value beyond a simple prediction.
7. **What does MAE mean?** Average absolute error in kWh.
8. **Why RMSE too?** It penalizes large errors more strongly.
9. **What is R²?** Improvement relative to a test-mean reference; it may be negative.
10. **Why chronological splitting?** It better reflects prediction into the future.
11. **What is leakage?** Using information unavailable at prediction time or derived from the target.
12. **Why pipelines?** They keep transformations fitted on training data within each fit.
13. **Why impute?** Many estimators cannot accept missing values directly.
14. **Why one-hot encoding?** It represents categories without implying numeric order.
15. **Why scale Ridge inputs?** Regularization is scale-sensitive.
16. **Do trees need scaling?** Usually not, but a shared pipeline can simplify comparisons.
17. **What does Random Forest do?** Averages predictions from randomized trees.
18. **What does boosting do?** Sequentially adds trees to reduce remaining loss.
19. **Why not choose the highest R² automatically?** Selection should reflect validation performance and business error costs.
20. **What is permutation importance?** Score degradation after shuffling one feature.
21. **Does importance prove causality?** No.
22. **What is a residual?** Actual minus predicted target.
23. **Does a high residual prove waste?** No; investigate regime, product, maintenance, sensors and uncertainty.
24. **Why is synthetic data used?** To test code when a verified suitable dataset is not available.
25. **Can synthetic results be attributed to Tata Steel?** No.
26. **What is distribution shift?** Deployment data differ from training data.
27. **How can model drift be monitored?** Track feature distributions, errors and calibration over time.
28. **How are savings estimated?** Difference in energy multiplied by a verified tariff; validate counterfactual assumptions.
29. **How are emissions estimated?** Energy difference times a verified emissions factor and matching boundary.
30. **Can the dashboard control equipment?** No; it is an advisory demonstration only.

## 15 challenging follow-up questions
1. How do you prove the target is aligned to production interval boundaries?
2. How would you model multiple furnaces or production lines without group leakage?
3. What happens if electricity consumption is autocorrelated?
4. How would you construct prediction intervals?
5. How would you handle a new product mix absent from training?
6. How do you detect a faulty meter versus a genuine process change?
7. What if the best model has lower RMSE but worse worst-case error?
8. How do you validate performance during startup and shutdown?
9. Why might correlated features make importance unstable?
10. How would you select a model under a strict latency limit?
11. How do you prevent unsafe optimization recommendations?
12. How would you estimate the cost of false alarms?
13. What evidence is required before claiming energy savings?
14. How would you monitor model drift after deployment?
15. What approvals and cybersecurity controls are needed before plant integration?

## Glossary
- **Target/label:** value the model learns to predict.
- **Feature:** input variable.
- **Leakage:** information unavailable at inference or derived from target.
- **MAE:** mean absolute error.
- **RMSE:** root mean squared error.
- **R²:** coefficient of determination.
- **Residual:** actual minus predicted.
- **Overfitting:** fitting training quirks that do not generalize.
- **Regularization:** penalty that discourages overly complex fits.
- **Permutation importance:** performance change after shuffling a feature.
- **Distribution shift:** change in input/target patterns after training.
- **Energy intensity:** energy per unit of output.
