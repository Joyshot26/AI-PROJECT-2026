# Machine Learning-Based Energy Efficiency Prediction and Optimization for Tata Steel

## Evidence status
This repository is an educational prototype. The default data is synthetic and is explicitly labelled `SYNTHETIC_DEMONSTRATION`. No model score or saving from that data is a Tata Steel finding.

## Abstract
This project demonstrates a reproducible regression workflow for predicting interval-level industrial electricity consumption. It includes synthetic data generation, chronological validation, baseline and tree-based models, evaluation metrics, diagnostic plots, a model artifact, and a small dashboard. The architecture is intended to be adapted to verified plant data.

## Problem and scope
Target: electricity consumption in kWh per 15-minute demonstration interval. This is not a claim about a particular Tata Steel plant, process route or meter boundary. Energy intensity (kWh/tonne) is a secondary metric when valid production data is present.

## Data
Default dataset: generated synthetic records with plausible directional relationships and noise. It is not calibrated to Tata Steel. A public alternative is the UCI Steel Industry Energy Consumption dataset (DOI: 10.24432/C52G8C), with 35,040 observations from a small-scale steel industry in South Korea. Its published fields do not include all production, temperature, raw material and machine-load variables requested here.

## Methodology
1. Generate data with fixed random seed.
2. Validate required columns and target values.
3. Sort chronologically and create train/validation/test segments.
4. Fit preprocessing within scikit-learn pipelines.
5. Compare DummyRegressor, Ridge, Random Forest and HistGradientBoosting.
6. Select on validation RMSE and evaluate the chosen model once on the final test segment.
7. Save model, metrics, predictions and diagnostic plots.

## Metrics
MAE and RMSE are in kWh; R² is unitless; sMAPE is reported as a percentage. Run the scripts to populate actual values for the generated data in `outputs/metrics/model_metrics.json`. Scores are not embedded in this report because they depend on execution and data version.

## Inefficiency analysis
A positive residual means observed consumption exceeds model expectation. Residuals should be reviewed over repeated periods and segmented by operating regime. A residual is not a causal diagnosis and should not automatically be called waste.

## Optimization
Compare only feasible scenarios. A real deployment needs engineer-approved constraints for production, quality, safety and equipment. The included scenario helper is a demonstration and does not control plant equipment.

## Business impact formulas
Energy saved (kWh) = baseline energy (kWh) - alternative energy (kWh).
Cost saved = energy saved (kWh) × applicable tariff (currency/kWh).
Emissions avoided = energy saved (kWh) × verified emissions factor (kg CO2e/kWh).
These calculations require verified meter boundaries, tariffs, emissions factors, uncertainty and implementation costs.

## Limitations and future work
Replace synthetic data with authorized plant data; confirm meter/production alignment and process boundary; include product mix and quality; validate on later time periods and separate assets; quantify prediction intervals; conduct engineer-reviewed trials; monitor drift and retrain under governance.
