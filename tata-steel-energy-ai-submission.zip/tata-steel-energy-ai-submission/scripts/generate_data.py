from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from steel_energy.data import save_synthetic_data

if __name__ == "__main__":
    path = save_synthetic_data("data/raw/synthetic_steel_energy.csv", rows=5000, seed=42)
    print(f"Created SYNTHETIC demonstration data: {path}")
