from pathlib import Path
import sys
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from steel_energy.modeling import train_and_evaluate, plot_diagnostics

if __name__ == "__main__":
    path = Path("data/raw/synthetic_steel_energy.csv")
    if not path.exists():
        raise SystemExit("Dataset not found. Run: python scripts/generate_data.py")
    df = pd.read_csv(path, parse_dates=["timestamp"])
    metrics, model, (X_test, y_test, pred) = train_and_evaluate(df)
    plot_diagnostics(y_test, pred)
    print("Selected model:", metrics["selected_model"])
    print("Held-out test metrics:", metrics["test_metrics"])
    print("Data origin:", metrics["data_origin"])
    print("Reminder: synthetic-demo metrics are not Tata Steel findings.")
