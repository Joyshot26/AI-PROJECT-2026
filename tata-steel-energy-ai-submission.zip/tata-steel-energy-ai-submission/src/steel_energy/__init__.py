"""Educational steel-industry energy ML project."""
__version__ = "0.1.0"
