"""Synthetic demo data and dataset validation helpers.

Synthetic rows are for software demonstration only, not evidence about Tata Steel.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

NUMERIC_FEATURES = [
    "production_tonnes", "raw_material_tonnes", "operating_hours",
    "machine_load_pct", "temperature_c", "ambient_temp_c",
    "previous_interval_energy_kwh"
]
CATEGORICAL_FEATURES = ["shift", "operating_regime"]
TARGET = "energy_kwh"

def make_synthetic_data(rows: int = 5000, seed: int = 42,
                        frequency_minutes: int = 15) -> pd.DataFrame:
    """Generate plausible *illustrative* interval-level data with deterministic noise."""
    if rows < 100:
        raise ValueError("rows must be at least 100")
    rng = np.random.default_rng(seed)
    timestamps = pd.date_range("2024-01-01", periods=rows,
                               freq=f"{frequency_minutes}min")
    regime = rng.choice(["steady", "startup", "maintenance"], rows,
                        p=[0.84, 0.10, 0.06])
    operating_hours = rng.uniform(0.05, 0.25, rows)
    operating_hours[regime == "startup"] *= rng.uniform(0.2, 0.8, (regime == "startup").sum())
    operating_hours[regime == "maintenance"] *= 0.1
    machine_load = np.clip(rng.normal(68, 16, rows), 5, 100)
    machine_load[regime == "maintenance"] *= 0.35
    temperature = np.clip(rng.normal(850, 65, rows), 650, 1050)
    ambient = rng.normal(24, 7, rows)
    production = np.maximum(0, (operating_hours * 60) * (machine_load / 100)
                            * rng.normal(1.8, 0.15, rows))
    production[regime == "maintenance"] *= 0.1
    raw_material = production * rng.normal(1.12, 0.04, rows)
    # Illustrative physics-inspired relationship; coefficients are synthetic assumptions.
    base = 42 + 2.6 * production + 0.18 * machine_load
    thermal = 0.012 * np.maximum(temperature - 700, 0)
    start_penalty = np.where(regime == "startup", 16, 0)
    maintenance_penalty = np.where(regime == "maintenance", 5, 0)
    noise = rng.normal(0, 7, rows)
    energy = np.maximum(1.0, base + thermal + start_penalty + maintenance_penalty
                        + 0.05 * raw_material + noise)
    previous = np.r_[energy[0], energy[:-1]]
    # A little realistic persistence in the target.
    energy = np.maximum(1.0, 0.82 * energy + 0.18 * previous)
    return pd.DataFrame({
        "timestamp": timestamps,
        "production_tonnes": production.round(3),
        "raw_material_tonnes": raw_material.round(3),
        "operating_hours": operating_hours.round(4),
        "machine_load_pct": machine_load.round(2),
        "temperature_c": temperature.round(2),
        "ambient_temp_c": ambient.round(2),
        "previous_interval_energy_kwh": previous.round(3),
        "shift": np.select(
            [timestamps.hour < 8, timestamps.hour < 16],
            ["night", "morning"], default="evening"),
        "operating_regime": regime,
        "energy_kwh": energy.round(3),
        "data_origin": "SYNTHETIC_DEMONSTRATION"
    })

def validate_frame(df: pd.DataFrame, target: str = TARGET) -> None:
    """Raise useful errors for missing columns, empty data, or invalid target values."""
    if df.empty:
        raise ValueError("Dataset is empty")
    required = set(NUMERIC_FEATURES + CATEGORICAL_FEATURES + [target])
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if not pd.api.types.is_numeric_dtype(df[target]):
        raise ValueError(f"Target '{target}' must be numeric")
    if df[target].isna().any():
        raise ValueError(f"Target '{target}' contains missing values")
    if (df[target] < 0).any():
        raise ValueError(f"Target '{target}' contains negative values")

def save_synthetic_data(path: str | Path, rows: int = 5000, seed: int = 42) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    make_synthetic_data(rows=rows, seed=seed).to_csv(path, index=False)
    return path
