"""Model interpretation helpers."""
from sklearn.inspection import permutation_importance
import pandas as pd

def permutation_importance_table(model, X, y, random_state=42):
    result = permutation_importance(model, X, y, n_repeats=8,
                                    random_state=random_state, scoring="neg_mean_absolute_error")
    return (pd.DataFrame({"feature": X.columns,
                          "importance_mean": result.importances_mean,
                          "importance_std": result.importances_std})
            .sort_values("importance_mean", ascending=False))
