"""Leakage-aware feature preparation."""
from __future__ import annotations
import pandas as pd

def add_safe_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "production_tonnes" in out and "energy_kwh" in out:
        denom = out["production_tonnes"].where(out["production_tonnes"] > 0)
        out["energy_intensity_kwh_per_tonne"] = out["energy_kwh"] / denom
    if "timestamp" in out:
        ts = pd.to_datetime(out["timestamp"], errors="coerce")
        out["hour"] = ts.dt.hour
        out["day_of_week"] = ts.dt.dayofweek
    if {"machine_load_pct", "temperature_c"}.issubset(out.columns):
        out["load_temperature_interaction"] = (
            out["machine_load_pct"] * out["temperature_c"]
        )
    return out

def predictor_columns(df: pd.DataFrame) -> list[str]:
    """Select predictors known at prediction time; never include target-derived intensity."""
    excluded = {"energy_kwh", "data_origin", "timestamp",
                "energy_intensity_kwh_per_tonne"}
    return [c for c in df.columns if c not in excluded]
