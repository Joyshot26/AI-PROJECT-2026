"""Chronological model training and artifact persistence."""
from __future__ import annotations
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from .data import NUMERIC_FEATURES, CATEGORICAL_FEATURES, TARGET, validate_frame

def chronological_split(df: pd.DataFrame, test_fraction: float = 0.20,
                        validation_fraction: float = 0.15):
    df = df.sort_values("timestamp").reset_index(drop=True)
    n = len(df)
    test_start = int(n * (1 - test_fraction))
    val_start = int(test_start * (1 - validation_fraction))
    return df.iloc[:val_start].copy(), df.iloc[val_start:test_start].copy(), df.iloc[test_start:].copy()

def build_pipeline(model, numeric_cols, categorical_cols):
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler())
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    prep = ColumnTransformer([
        ("numeric", numeric, numeric_cols),
        ("categorical", categorical, categorical_cols)
    ], remainder="drop")
    return Pipeline([("preprocess", prep), ("model", model)])

def metric_dict(y_true, y_pred):
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    mae = float(mean_absolute_error(y_true, y_pred))
    denom = np.maximum(np.abs(np.asarray(y_true)), 1.0)
    return {"MAE_kWh": mae, "RMSE_kWh": rmse,
            "R2": float(r2_score(y_true, y_pred)),
            "sMAPE_pct": float(np.mean(
                2 * np.abs(np.asarray(y_true) - np.asarray(y_pred)) /
                (np.abs(np.asarray(y_true)) + np.abs(np.asarray(y_pred)) + 1e-8)
            ) * 100)}

def train_and_evaluate(df: pd.DataFrame, output_dir="outputs", seed=42):
    validate_frame(df)
    train, val, test = chronological_split(df)
    # Features must be available before the target interval closes.
    numeric_cols = [c for c in NUMERIC_FEATURES if c in df.columns]
    categorical_cols = [c for c in CATEGORICAL_FEATURES if c in df.columns]
    feature_cols = numeric_cols + categorical_cols
    X_train, y_train = train[feature_cols], train[TARGET]
    X_val, y_val = val[feature_cols], val[TARGET]
    X_test, y_test = test[feature_cols], test[TARGET]
    candidates = {
        "DummyMean": DummyRegressor(strategy="mean"),
        "LinearRegression": LinearRegression(),
        "Ridge": Ridge(alpha=2.0),
        "RandomForest": RandomForestRegressor(
            n_estimators=160, max_depth=12, min_samples_leaf=3,
            random_state=seed, n_jobs=-1),
        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=180, learning_rate=0.08, l2_regularization=1.0,
            random_state=seed)
    }
    fitted, val_scores = {}, {}
    for name, model in candidates.items():
        pipe = build_pipeline(model, numeric_cols, categorical_cols)
        pipe.fit(X_train, y_train)
        fitted[name] = pipe
        val_scores[name] = metric_dict(y_val, pipe.predict(X_val))
    # Select by validation RMSE; final test remains untouched until this point.
    best_name = min(val_scores, key=lambda n: val_scores[n]["RMSE_kWh"])
    best = build_pipeline(candidates[best_name], numeric_cols, categorical_cols)
    train_val = pd.concat([train, val], ignore_index=True)
    best.fit(train_val[feature_cols], train_val[TARGET])
    test_pred = best.predict(X_test)
    test_scores = metric_dict(y_test, test_pred)
    out = Path(output_dir)
    (out / "models").mkdir(parents=True, exist_ok=True)
    (out / "metrics").mkdir(parents=True, exist_ok=True)
    (out / "figures").mkdir(parents=True, exist_ok=True)
    joblib.dump(best, out / "models" / "energy_model.joblib")
    metadata = {
        "selected_model": best_name, "features": feature_cols,
        "target": TARGET, "target_unit": "kWh per interval",
        "data_origin": str(df["data_origin"].iloc[0]) if "data_origin" in df else "UNVERIFIED",
        "validation_metrics": val_scores, "test_metrics": test_scores,
        "note": "Results apply only to the dataset used; synthetic results are not Tata Steel findings."
    }
    (out / "metrics" / "model_metrics.json").write_text(json.dumps(metadata, indent=2))
    preds = pd.DataFrame({"actual_kwh": y_test.to_numpy(), "predicted_kwh": test_pred})
    preds["residual_kwh"] = preds["actual_kwh"] - preds["predicted_kwh"]
    preds.to_csv(out / "metrics" / "test_predictions.csv", index=False)
    return metadata, best, (X_test, y_test, test_pred)

def plot_diagnostics(y_true, y_pred, output_dir="outputs/figures"):
    import matplotlib.pyplot as plt
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    residuals = np.asarray(y_true) - np.asarray(y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(y_true, y_pred, alpha=0.45)
    lo = min(np.min(y_true), np.min(y_pred)); hi = max(np.max(y_true), np.max(y_pred))
    ax.plot([lo, hi], [lo, hi], linestyle="--")
    ax.set(xlabel="Actual energy (kWh)", ylabel="Predicted energy (kWh)",
           title="Predicted vs actual — held-out chronological test")
    fig.tight_layout(); fig.savefig(out / "predicted_vs_actual.png", dpi=140); plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(y_pred, residuals, alpha=0.45)
    ax.axhline(0, linestyle="--")
    ax.set(xlabel="Predicted energy (kWh)", ylabel="Residual (actual - predicted)",
           title="Residual diagnostic")
    fig.tight_layout(); fig.savefig(out / "residuals.png", dpi=140); plt.close(fig)
