"""Transparent scenario comparisons; outputs are exploratory, not control instructions."""
from __future__ import annotations
import pandas as pd

def compare_scenarios(model, baseline: dict, scenarios: list[dict],
                      feature_columns: list[str], production_min: float | None = None,
                      load_limits=(5.0, 100.0)) -> pd.DataFrame:
    rows = []
    all_scenarios = [{"scenario": "baseline", **baseline}] + [
        {"scenario": f"alternative_{i+1}", **s} for i, s in enumerate(scenarios)
    ]
    for item in all_scenarios:
        row = {k: v for k, v in item.items() if k != "scenario"}
        if "machine_load_pct" in row and not (load_limits[0] <= row["machine_load_pct"] <= load_limits[1]):
            rows.append({"scenario": item["scenario"], "feasible_under_demo_limits": False,
                         "predicted_energy_kwh": None, "note": "Outside illustrative load bounds"})
            continue
        if production_min is not None and row.get("production_tonnes", 0) < production_min:
            rows.append({"scenario": item["scenario"], "feasible_under_demo_limits": False,
                         "predicted_energy_kwh": None, "note": "Production target not met"})
            continue
        X = pd.DataFrame([{c: row[c] for c in feature_columns}])
        pred = float(model.predict(X)[0])
        rows.append({"scenario": item["scenario"], "feasible_under_demo_limits": True,
                     "predicted_energy_kwh": pred, "note": "Requires process-engineer review"})
    return pd.DataFrame(rows)
