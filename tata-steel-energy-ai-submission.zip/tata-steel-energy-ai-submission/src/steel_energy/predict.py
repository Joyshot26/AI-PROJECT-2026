"""Validated inference helpers."""
from pathlib import Path
import joblib
import pandas as pd

def load_model(path="outputs/models/energy_model.joblib"):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Model not found at {path}. Run scripts/train.py first.")
    return joblib.load(path)

def predict_energy(model, records: pd.DataFrame) -> pd.Series:
    required = set(getattr(model, "feature_names_in_", records.columns))
    missing = required - set(records.columns)
    if missing:
        raise ValueError(f"Missing inference features: {sorted(missing)}")
    prediction = model.predict(records[list(required)])
    return pd.Series(prediction, name="predicted_energy_kwh")
