import pandas as pd
import pytest
from steel_energy.data import make_synthetic_data, validate_frame
from steel_energy.features import add_safe_features
from steel_energy.modeling import metric_dict

def test_synthetic_data_schema_and_repeatability():
    a = make_synthetic_data(rows=120, seed=7)
    b = make_synthetic_data(rows=120, seed=7)
    assert list(a.columns) == list(b.columns)
    pd.testing.assert_frame_equal(a, b)
    validate_frame(a)

def test_validation_rejects_missing_column():
    df = make_synthetic_data(rows=120)
    with pytest.raises(ValueError, match="Missing required columns"):
        validate_frame(df.drop(columns=["machine_load_pct"]))

def test_safe_features_avoids_division_by_zero_crash():
    df = pd.DataFrame({"production_tonnes": [0.0, 2.0], "energy_kwh": [4.0, 10.0]})
    result = add_safe_features(df)
    assert pd.isna(result.loc[0, "energy_intensity_kwh_per_tonne"])
    assert result.loc[1, "energy_intensity_kwh_per_tonne"] == 5.0

def test_metrics_are_finite():
    result = metric_dict([10, 20, 30], [11, 18, 29])
    assert result["MAE_kWh"] >= 0
    assert result["RMSE_kWh"] >= result["MAE_kWh"]
    assert -1 <= result["R2"] <= 1
